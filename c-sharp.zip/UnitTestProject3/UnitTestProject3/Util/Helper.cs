﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.IO;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System.Reflection;
using OpenQA.Selenium.Remote;

namespace QAAutomationTask.util
{
    class Helper
    {
        private static String DriverName;
        private static String Url;
        private static String SettingValue;
        private static IWebDriver Driver;
        private static IWebElement element;
        private static Actions Action;
        private static WebDriverWait wait;
        private static List<IWebElement> MultipleWebElementList;
        private static List<String> MultipleElementTextList;

        public static void Click(By location)
        {
            WebpageHasLoaded();
            WaitForElementToLoad(location);
            ElementIsDisplayed(location);
            FindElement(location).Click();            
        }

        public static String ReadSetting(string key)
        {
            try
            {
                var appSettings = ConfigurationManager.AppSettings;
                SettingValue = appSettings[key] ?? "Not Found";                
            }
            catch (ConfigurationErrorsException)
            {
                Console.WriteLine("Error reading app settings");
            }
            
            return SettingValue;
        }

        public static void GoToUrl(String url)
        {
            Driver.Navigate().GoToUrl(url);
        }

        public static String GetCurrentUrl()
        {
            return Driver.Url;
        }

        public static String GetText(By location)
        {
            return FindElement(location).Text;
        }

        public static void SetUp()
        {

            String chromeDriverPath = @"C:\Users\nbakht\Documents\visual studio 2017\Projects\UnitTestProject3\UnitTestProject3\Drivers";
            ChromeOptions Options = new ChromeOptions();
            Options.AddArgument("--verbose");
            Options.AddArgument("test-type");
            Options.AddArgument("start-maximized");
            Driver = new ChromeDriver(chromeDriverPath, Options);    

            DeleteAllCookies();

            Action = new Actions(Driver);
        }

        public static void TearDown()
        {
                //DeleteAllCookies();
                Driver.Quit();
        }

        private static void TypeElement(By location, String text)
        {
            FindElement(location).SendKeys(text);
        }

        public static void TypeInputTextArea(By location, String text)
        {
            TypeElement(location, text);
        }

        public static void TypeInputTextBox(By location, String text)
        {
            TypeElement(location, text);
        }

        private static List<IWebElement> FindElements(By location)
        {
            return UsingElements(location);
        }

        public static List<String> GetTextOfMultipleElements(By location)
        {
            MultipleWebElementList = FindElements(location);
            MultipleElementTextList = new List<String>();

            for (int i = 0; i < MultipleWebElementList.Count; i++)
            {
                MultipleElementTextList.Add(MultipleWebElementList[i].Text);
            }

            return MultipleElementTextList;
        }

        private static IWebElement FindElement(By location)
        {
            return UsingElement(location);
        }

        public static IWebElement UsingElement(By elementLocation)
        {
            WaitForElementToLoad(elementLocation);
            return Driver.FindElement(elementLocation);
        }

        public static List<IWebElement> UsingElements(By elementLocation)
        {
            WaitForElementToLoad(elementLocation);
            return new List<IWebElement>(Driver.FindElements(elementLocation));
        }

        private static IWebElement WaitForElementToLoad(By location)
        {
            ElementLoaded(location);
            return element;
        }

        private static void ElementLoaded(By location)
        {
            wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            element = wait.Until(ExpectedConditions.ElementToBeClickable(location));
        }

        public static void WebpageHasLoaded()
        {
            Driver.Manage().Timeouts().AsynchronousJavaScript = TimeSpan.FromMilliseconds(30);
            //DeleteAllCookies();
	    }

        public static void DeleteAllCookies()
        {
            Driver.Manage().Cookies.DeleteAllCookies();
        }

        public static void IgnoreOverLay(By location)
        {
            new WebDriverWait(Driver, TimeSpan.FromSeconds(30)).Until(ExpectedConditions.InvisibilityOfElementLocated(location));
            Driver.SwitchTo().DefaultContent();
        }

        public static Boolean ElementIsDisplayed(By location)
        {
            try
            {
                ElementLoaded(location);
                return true;
            }
            catch (AmbiguousMatchException)
            {
                return false;
            }
        }


    }
}
