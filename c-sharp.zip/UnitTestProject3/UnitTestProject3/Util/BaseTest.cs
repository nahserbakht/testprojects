﻿using System;
using System.Collections.Generic;
using QAAutomationTask.util;

namespace QAAutomationTask
{
    public class BaseTest
    {
        private List<int> WholeNumbersNumericList;

        protected void SetUp()
        {
            Helper.SetUp();
        }

        protected void TearDown()
        {
            Helper.TearDown();
        }

        protected List<int> ConvertListToWholeNumbers(List<String> decimalNumbersList)
        {
            WholeNumbersNumericList = new List<int>();

            for (int i = 0; i < decimalNumbersList.Count; i++)
            {

                String RatingData = decimalNumbersList[i];
                String WholeNumberSubString = RatingData.Substring(0, 1);

                WholeNumbersNumericList.Add((int) Convert.ToDouble(WholeNumberSubString));
            }

            return WholeNumbersNumericList;
        }
    }
}
