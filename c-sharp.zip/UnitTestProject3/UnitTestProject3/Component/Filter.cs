﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using QAAutomationTask.util;

namespace QAAutomationTask.Component
{
    class Filter
    {
        By MoreFilterOptions;
        By LessFilterOptions;
        By CustomerRatingOptionsLink;
        By CustomerRatingOption;
        int CustomerRating;

        public Filter()
        {
            BuildComponent();
        }

        private void BuildComponent()
        {
            MoreFilterOptions = By.XPath("//div[contains(text(), 'more filter options')]");
            LessFilterOptions = By.XPath("//div[contains(text(), 'less filter options')]");
            CustomerRatingOptionsLink = By.LinkText("Customer Rating");
        }

        public void ClickMoreFilterOptions()
        {
            if (Helper.ElementIsDisplayed(MoreFilterOptions))
            {
                Helper.Click(MoreFilterOptions);
            }
            else if (Helper.ElementIsDisplayed(LessFilterOptions))
            {
                Helper.Click(LessFilterOptions);
                Helper.Click(MoreFilterOptions);
            }
        }

        public void ClickCustomerRatingLink()
        {
            if (Helper.ElementIsDisplayed(CustomerRatingOptionsLink))
            {
                Helper.Click(CustomerRatingOptionsLink);
            }
            else if (Helper.ElementIsDisplayed(MoreFilterOptions))
            {
                Helper.Click(MoreFilterOptions);
                Helper.Click(CustomerRatingOptionsLink);
            }
        }


        public void CustomerRatingValueOf(int customerRating)
        {
            this.CustomerRating = customerRating;
        }

        public void ClickCustomerRatingFromSelection()
        {
            if (Helper.ElementIsDisplayed(BuildCustomerRatingFromSelectionComponent()))
            {
                Helper.Click(BuildCustomerRatingFromSelectionComponent());
            }
            else
            {
                ClickCustomerRatingLink();
                Helper.Click(BuildCustomerRatingFromSelectionComponent());
            }
        }

        private By BuildCustomerRatingFromSelectionComponent()
        {
            return By.XPath("//li[@id='fv_" + CustomerRating + "2d0andabove']//a");
        }
    }
}
