﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using QAAutomationTask.util;

namespace QAAutomationTask.Component
{
    class Header
    {
        private By homeLogo;
        private Search SearchComponent;

        public Header()
        {
            BuildComponent();
        }

        private void BuildComponent()
        {
            homeLogo = By.ClassName("aoSiteLogoLink");
            Search SearchComponent = new Search();
        }

        public void clickHomeLogo()
        {
            Helper.Click(homeLogo);
        }

        public Search Search()
        {
            return SearchComponent;
        }
    }
}
