﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using QAAutomationTask.util;

namespace QAAutomationTask.Component
{
    class Search
    {
        By searchTextBox;
        By searchButton;

        public Search()
        {
            BuildComponent();
        }

        private void BuildComponent()
        {
            searchTextBox = By.Id("searchAOL");
            searchButton = By.Id("lbSearch");
        }

        public void ClickSearchButton()
        {

            Helper.Click(searchButton);
        }

        public void ClickSearchTextBox()
        {
            Helper.Click(searchTextBox);
        }

        public void TypeSearchInputTextBox(String text)
        {
            Helper.TypeInputTextBox(searchTextBox, text);
        }
    }
}
