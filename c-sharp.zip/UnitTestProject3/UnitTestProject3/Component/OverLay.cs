﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using QAAutomationTask.util;

namespace UnitTestProject3.Component
{
    class OverLay
    {
        private By OverLayLocation;

        public OverLay()
        {
            BuildComponent();
        }

        private void BuildComponent()
        {
            OverLayLocation = By.Id("widgetContainer");
        }

        public void IgnoreOverLay()
        {
            Helper.IgnoreOverLay(OverLayLocation);
        }
    }
}
