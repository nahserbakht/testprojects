﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using QAAutomationTask.Component;
using QAAutomationTask.util;

namespace QAAutomationTask.Page
{
    class SearchResultBrand : Page
    {
        By BrandNameTitle;
        Filter FilterComponent;
        By CustomerRatings;

        public SearchResultBrand() : base("searchResultBrand")
        {            
            BuildPage();
        }

        private void BuildPage()
        {
            BrandNameTitle = By.Id("SeoTitle");
            CustomerRatings = By.XPath("//span[@id='ratingText']");
            FilterComponent = new Filter();
        }

        public String GetBrandNameTitle()
        {
            return Helper.GetText(BrandNameTitle);
        }

        public Filter Filter()
        {
            return FilterComponent;
        }

        public List<String> GetCustomerRatings()
        {
            return Helper.GetTextOfMultipleElements(CustomerRatings);
        }
    }
}
