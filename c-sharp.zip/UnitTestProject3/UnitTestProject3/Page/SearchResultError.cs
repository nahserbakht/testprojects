﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using QAAutomationTask.util;

namespace QAAutomationTask.Page
{
    class SearchResultError : Page
    {
        By ErrorMessageTitle;

        public SearchResultError() : base("searchResultError")
        {            
            BuildPage();
        }

        private void BuildPage()
        {
            ErrorMessageTitle = By.XPath("//div[@id='zeroResultsWrapper']//h1");
        }

        public String GetErrorMessageTitle()
        {
            return Helper.GetText(ErrorMessageTitle);
        }

        public bool isErrorMessageDisplayed()
        {
            return Helper.ElementIsDisplayed(ErrorMessageTitle);
        }
    }
}
