﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QAAutomationTask.util;

namespace QAAutomationTask.Page
{
    class Page
    {
        private String name;

        public Page(String name)
        {
            this.name = name;
        }

        public String GetName()
        {
            return name;
        }

        public void GoToPage()
        {
            Helper.GoToUrl("http://ao.com/");
            Helper.WebpageHasLoaded();
            //Helper.DeleteAllCookies();
        }

        public String GetCurrentUrl()
        {
            return Helper.GetCurrentUrl();
        }
    }
}
