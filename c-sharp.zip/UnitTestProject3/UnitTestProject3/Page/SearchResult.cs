﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using QAAutomationTask.util;

namespace QAAutomationTask.Page
{
    class SearchResult : Page
    {
        By MainTitle;
        By BrandNameLink;

        public SearchResult() : base("SearchResult")
        {
            BuildPage();
        }

        private void BuildPage()
        {
            MainTitle = By.ClassName("main-title");
        }

        public String GetMainTitle()
        {
            return Helper.GetText(MainTitle);
        }

        public void ClickBrandNameLink(String BrandName)
        {
            BuildBrandNameLink(BrandName);
            Helper.Click(BrandNameLink);
        }

        private void BuildBrandNameLink(String BrandName)
        {
            BrandNameLink = By.LinkText(BrandName);
        }
    }
}
