﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QAAutomationTask.Component;
using QAAutomationTask.Page;

namespace QAAutomationTask.Page
{
    class Home : Page
    {

        private Header HeaderComponent;

        public Home() : base("home")
        {
            BuildPage();
        }

        private void BuildPage()
        {
            HeaderComponent = new Header();
        }

        public Header Header()
        {
            return HeaderComponent;
        }
    }
}
