﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using QAAutomationTask.Page;
using TechTalk.SpecFlow;
using QAAutomationTask.Component;
using QAAutomationTask.util;
using UnitTestProject3.Component;

namespace QAAutomationTask
{
    [Binding]
    public class QAAutomationTaskSteps : BaseTest
    {
        Home Home;
        SearchResult SearchResult;
        SearchResultBrand SearchResultBrand;
        SearchResultError SearchResultError;
        List<int> ActualCustomerRatingsList;
        int ExpectedCustomerRating;
        OverLay OverLay;
        String ActualSearchResultTitle;
        String ActualBrandName;

        [BeforeScenario]
        public void BeforeScenarioSetUp()
        {
            base.SetUp();
            Home = new Home();
            SearchResult = new SearchResult();
            SearchResultBrand = new SearchResultBrand();
            SearchResultError = new SearchResultError();
            ActualCustomerRatingsList = new List<int>();
            ExpectedCustomerRating = -1;
            OverLay = new OverLay();
            ActualSearchResultTitle = new String(new char[] {});
            ActualBrandName = new String(new char[] { });
        }

        [AfterScenario]
        public void AfterFeatureSetUp()
        {
            base.TearDown();
        }

        [Given(@"I am on the AO website")]
        public void GivenIAmOnTheAOWebsite()
        {
            // Arrange 
            String ExpectedUrl = "http://ao.com/";

            // Act
            Home.GoToPage();

            // Assert
            Assert.AreEqual(ExpectedUrl, Home.GetCurrentUrl());
        }
        
        [When(@"I click on the search engine text box")]
        public void WhenIClickOnTheSearchEngineTextBox()
        {
            //ScenarioContext.Current.Pending();
        }
        
        [When(@"I type in the search term ""(.*)""")]
        public void WhenITypeInTheSearchTerm(string p0)
        {
            //ScenarioContext.Current.Pending();
        }

        [When(@"I click on the search button")]
        public void WhenIClickOnTheSearchButton()
        {
            //ScenarioContext.Current.Pending();
        }

        [When(@"I filter the results by the brand name ""(.*)""")]
        public void WhenIFilterTheResultsByTheBrandName(string p0)
        {
            //ScenarioContext.Current.Pending();
        }

        [When(@"I filter the results by the customer rating of ""(.*)"" stars")]
        public void WhenIFilterTheResultsByTheCustomerRatingOfStars(int p0)
        {
            //ScenarioContext.Current.Pending();
        }

        [Then(@"I should get a set of results based on the product type of ""(.*)""")]
        public void ThenIShouldGetASetOfResultsBasedOnTheProductTypeOf(string p0)
        {
            //ScenarioContext.Current.Pending();
        }

        [Then(@"I should get a set of results based on the product brand name with heading of ""(.*)""")]
        public void ThenIShouldGetASetOfResultsBasedOnTheProductBrandNameWithHeadingOf(string p0)
        {
            //ScenarioContext.Current.Pending();
        }

        [Then(@"I should get a set of results based on the customer rating of ""(.*)"" stars or above")]
        public void ThenIShouldGetASetOfResultsBasedOnTheCustomerRatingOfStarsOrAbove(int p0)
        {
            //ScenarioContext.Current.Pending();
        }

        [Then(@"I should get an appropriate error message of We don't quite understand ""(.*)""\.")]
        public void ThenIShouldGetAnAppropriateErrorMessageOfWeDonTQuiteUnderstand_(string p0)
        {
            //ScenarioContext.Current.Pending();
        }
    }
}
