package com.ao.qa.automation.task.component;

import org.openqa.selenium.By;

import com.ao.qa.automation.task.util.Helper;

public class OverLay
{
	private By overLayLocation;

	public OverLay()
	{
		buildComponent();
	}

	private void buildComponent()
	{
		overLayLocation = By.id("widgetContainer");
	}
	
	public void ignoreOverLay()
	{
		Helper.ignoreOverLay(overLayLocation);
	}
}