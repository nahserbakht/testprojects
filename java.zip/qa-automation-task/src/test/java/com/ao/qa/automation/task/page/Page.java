package com.ao.qa.automation.task.page;

import com.ao.qa.automation.task.util.Helper;
import com.ao.qa.automation.task.util.PropertiesAccessor;

public class Page 
{
	private String name;
	private PropertiesAccessor propertiesAcecssor;

	public Page(String name) 
	{
		this.name = name;
		propertiesAcecssor = new PropertiesAccessor();		
	}

	public String getName() 
	{
		return name;
	}	
	
	public void goToPage()
	{
		Helper.deleteAllCookies();
		Helper.goToUrl(propertiesAcecssor.getPropValue(name));
		Helper.webpageHasLoaded();
		Helper.deleteAllCookies();
	}
	
	public String getCurrentUrl()
	{
		return Helper.getCurrentUrl();		
	}
}