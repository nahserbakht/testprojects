package com.ao.qa.automation.task.page;

import java.util.List;

import org.openqa.selenium.By;

import com.ao.qa.automation.task.component.Filter;
import com.ao.qa.automation.task.util.Helper;

public class SearchResultBrand extends Page
{
		By brandNameTitle;
		Filter filter;
		By customerRatings;
		
		public SearchResultBrand()
		{
			super("searchResultBrand");
			buildPage();
		}

		private void buildPage()
		{
			brandNameTitle = By.id("SeoTitle");
			customerRatings = By.xpath("//span[@id='ratingText']");
			filter = new Filter();			
		}

		public String getBrandNameTitle()
		{
			return Helper.getText(brandNameTitle);
		}		
		
		public Filter filter()
		{
			return filter;
		}

		public List<String> getCustomerRatings()
		{
			return Helper.getTextOfMultipleElements(customerRatings);
		}
}