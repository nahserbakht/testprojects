package com.ao.qa.automation.task.util;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Helper
{
	private static String driverName;
	private static WebDriver driver;
	private static File file;
	private static Actions action;
	private static List<WebElement> multipleWebElementList;
	private static List<String> multipleElementTextList;
	
	public static void click(By location)
	{		
		webpageHasLoaded();
		waitForElementToLoad(location);
		elementIsDisplayed(location);
		findElement(location).click();
	}
	
	public static void actionClick(By location)
	{		
		webpageHasLoaded();
		waitForElementToLoad(location);
		hoverOver(location);
	}
	
	private static WebElement findElement(By location)
	{
		return usingElement(location);
	}
	
	private static List<WebElement> findElements(By location)
	{
		return usingElements(location);
	}
	
	public static String getCurrentUrl()
	{
		return driver.getCurrentUrl();		
	}
	
	public static String getText(By location)
	{
		return findElement(location).getText();
	}
	
	public static List<String> getTextOfMultipleElements(By location)
	{	
		multipleWebElementList = findElements(location);
		multipleElementTextList = new ArrayList<String>();
		
		for (int i = 0; i < multipleWebElementList.size(); i++) 
		{
			multipleElementTextList.add(multipleWebElementList.get(i).getText());
		}
		
		return multipleElementTextList;
	}
	
	public static void goToUrl(String url)
	{
		driver.get(url);		
	}
	
	public static void hoverOver(By location)
	{
		action.moveToElement(findElement(location)).click().build().perform();
	}
	
	public static void ignoreOverLay(By location)
	{		
		new WebDriverWait(driver, 10).until(ExpectedConditions.invisibilityOfElementLocated(location));
		driver.switchTo().defaultContent();
	}
	
	public static void selectChechBoxes(By location[])
	{
		selectMultipleEelements(location);
	}
	
	public static void selectDropDown(By location[])
	{
		selectMultipleEelements(location);
	}
	
	private static void selectMultipleEelements(By location[])
	{
		for ( int i = 0; i <= location.length; i++ )
		{	
		
			if ( ! findElement(location[i]).isSelected() )
			{
				findElement(location[i]).click();
			}
		
		}
	}
	
	public static void selectMultipleList(By location[])
	{
		selectMultipleEelements(location);
	}
	
	public static void selectRadioButton(By location)
	{
		click(location);
	}
	
	private static void setDriverSystemProperty(String driverSystemProperty, File file)
	{
		System.setProperty(driverSystemProperty, file.getAbsolutePath());
	}
	
	public static void setUp()
	{
		driverName =  "chromedriver";
		file = new File( "client-drivers/" + driverName + ".exe" );		
		
		if (driverName == "chromedriver")
		{
			setDriverSystemProperty("webdriver.chrome.driver", file);
			
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("incognito");
			options.addArguments("--start-maximized");
			
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
			capabilities.setCapability("chrome.switches", Arrays.asList("--incognito"));
			


			driver = new ChromeDriver(capabilities);
			Helper.deleteAllCookies();
			
			action = new Actions(driver);
		}
		else
		{
			System.err.println("Incorrect Driver Type: " + driverName); 
		}		
	}
	
	public static void tearDown()
	{
		if (driver != null)
		{
			deleteAllCookies();
			driver.quit();
		}
		
		driver = null;
	}
	
	private static void typeElement(By location, String text)
	{
		findElement(location).sendKeys(text);
	}
	
	public static void typeInputTextArea(By location, String text)
	{
		typeElement(location, text);
	}
	
	public static void typeInputTextBox(By location, String text)
	{
		typeElement(location, text);
	}
	
	public static WebElement usingElement(By elementLocation)
	{
		waitForElementToLoad(elementLocation);		
		return driver.findElement(elementLocation);
	}
	
	public static List<WebElement> usingElements(By elementLocation)
	{
		waitForElementToLoad(elementLocation);
		return driver.findElements(elementLocation);
	}
	
	private static WebElement waitForElementToLoad(By location)
	{		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(location));
		return element;		    
	}
	
	public static void webpageHasLoaded()
	{
        ExpectedCondition<Boolean> expectation = new
        ExpectedCondition<Boolean>() 
        {
            public Boolean apply(WebDriver driver) 
            {
              return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
            }
         };

          WebDriverWait wait = new WebDriverWait(driver,30);
          try 
          {
                  wait.until(expectation);
          } 
          catch(Throwable error) 
          {
                  System.err.println( "Timeout waiting for Page Load Request to complete.");
          }
	
          deleteAllCookies();
	}
	
	public static void deleteAllCookies()
	{
		driver.manage().deleteAllCookies();
	}
	
	public static boolean elementIsDisplayed(By location)
	{
		try
		{
		   WebDriverWait wait = new WebDriverWait(driver, 10);
		   wait.until(ExpectedConditions.elementToBeClickable(location));
		   return true;
		}
		catch (Exception e)
		{
		  return false;
		}
	}
}