package com.ao.qa.automation.task.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesAccessor
{
	private String result;
	InputStream inputStream;
	Properties prop;
	String propFileName;
	
	public PropertiesAccessor()
	{
		result = "";
		prop = new Properties();
		propFileName = "config/config.properties";
		inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
	}
	
	public String getPropValue(String propKey)
	{		
		try (InputStream inputStream = new FileInputStream(propFileName))
		{
			prop.load(inputStream);
			result = prop.getProperty(propKey);			
			inputStream.close();
		} 
		catch (Exception e)
		{
			System.err.println("Exception: " + e);
		}
		
		return result;
	}
}