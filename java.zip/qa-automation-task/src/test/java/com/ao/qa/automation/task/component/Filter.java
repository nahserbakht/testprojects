package com.ao.qa.automation.task.component;

import org.openqa.selenium.By;

import com.ao.qa.automation.task.util.Helper;

public class Filter
{
	By moreFilterOptions;
	By lessFilterOptions;
	By customerRatingOptionsLink;
	By customerRatingOption;
	int customerRating;
	
	public Filter()
	{	
		buildComponent();
	}
	
	private void buildComponent()
    {
		moreFilterOptions = By.xpath("//div[contains(text(), 'more filter options')]");
		lessFilterOptions = By.xpath("//div[contains(text(), 'less filter options')]");
		customerRatingOptionsLink = By.linkText("Customer Rating");
    }    
	
	public void clickMoreFilterOptions()
	{
		if(Helper.elementIsDisplayed(moreFilterOptions))
		{		
			Helper.click(moreFilterOptions);
		} 
		else if(Helper.elementIsDisplayed(lessFilterOptions))
		{
			Helper.click(lessFilterOptions);
			Helper.click(moreFilterOptions);
		}
	}
	
	/*
	public void clickCustomerRatingOption()
	{
		Helper.click(customerRatingOption);
	}	
	*/
	
	
	public void clickCustomerRatingLink()
	{		
		if(Helper.elementIsDisplayed(customerRatingOptionsLink))
		{		
			Helper.click(customerRatingOptionsLink);
		} 
		else if(Helper.elementIsDisplayed(moreFilterOptions))
		{
			Helper.click(moreFilterOptions);
			Helper.click(customerRatingOptionsLink);
		}
	}	
	
	
	public void customerRatingValueOf(int customerRating)
	{
		this.customerRating = customerRating;
	}

	public void clickCustomerRatingFromSelection()
	{
		if(Helper.elementIsDisplayed(buildCustomerRatingFromSelectionComponent()))
		{		
			Helper.click(buildCustomerRatingFromSelectionComponent());
		}
		else
		{
			clickCustomerRatingLink();
			Helper.click(buildCustomerRatingFromSelectionComponent());
		}
	}
	
	private By buildCustomerRatingFromSelectionComponent()
	{
		return By.xpath("//li[@id='fv_" + customerRating + "2d0andabove']//a");
	}
}