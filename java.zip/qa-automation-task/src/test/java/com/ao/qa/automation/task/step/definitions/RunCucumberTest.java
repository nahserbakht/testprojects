package com.ao.qa.automation.task.step.definitions; 

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith; 
 
@RunWith(Cucumber.class) 
@CucumberOptions(
		plugin = {"pretty", "html:target/cucumber"},
        features = "src/test/resources/com/ao/qa/automation/task/features/",        		
        glue = "com.ao.qa.automation.task.step.definitions"
		) 

public class RunCucumberTest 
{ 
	
}