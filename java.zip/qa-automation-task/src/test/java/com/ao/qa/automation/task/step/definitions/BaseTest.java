package com.ao.qa.automation.task.step.definitions;

import java.util.ArrayList;
import java.util.List;

import com.ao.qa.automation.task.util.Helper;

public class BaseTest
{
	private List<Integer> wholeNumbersNumericList;
	
	protected void setUp()
	{
		Helper.setUp();		
	}

	protected void tearDown()
	{
		Helper.tearDown();		
	}
	
	protected List<Integer> convertListToWholeNumbers(List<String> decimalNumbersList)
	{
		wholeNumbersNumericList =  new ArrayList<Integer>();
		
		for (int i = 0; i < decimalNumbersList.size(); i++) 
		{

			String ratingData = decimalNumbersList.get(i);
			String wholeNumberSubString = ratingData.substring(0, 1);			
			
			wholeNumbersNumericList.add((int) Double.parseDouble(wholeNumberSubString));
		}
		
		return wholeNumbersNumericList;
	}
}