package com.ao.qa.automation.task.page;

import com.ao.qa.automation.task.component.Header;

public class Home extends Page
{
	private Header header;
	
	public Home()
	{
		super("home");
		buildPage();
	}

	private void buildPage()
	{		
		header = new Header();
	}
	
	public Header header()
	{
		return header;
	}
}