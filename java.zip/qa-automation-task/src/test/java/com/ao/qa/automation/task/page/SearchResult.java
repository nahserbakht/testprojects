package com.ao.qa.automation.task.page;

import org.openqa.selenium.By;

import com.ao.qa.automation.task.util.Helper;

public class SearchResult extends Page
{
	By mainTitle;
	By brandNameLink;	
	
	public SearchResult()
	{
		super("searchResult");
		buildPage();
	}

	private void buildPage()
	{
		mainTitle = By.className("main-title");		
	} 

	public String getMainTitle()
	{
		return Helper.getText(mainTitle);
	}

	public void clickBrandNameLink(String brandName)
	{
		buildBrandNameLink(brandName);
		Helper.click(brandNameLink);
	}
	
	private void buildBrandNameLink(String brandName)
	{
		brandNameLink = By.linkText(brandName);
	}
}