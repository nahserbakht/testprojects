package com.ao.qa.automation.task.component;

import org.openqa.selenium.By;

import com.ao.qa.automation.task.util.Helper;

public class Search
{	
		By searchTextBox;
		By searchButton;
		
		public Search()
		{	
			buildComponent();
		}
		
		private void buildComponent()
	    {
			searchTextBox = By.id("searchAOL");
			searchButton = By.id("lbSearch");			
	    }    
		
		public void clickSearchButton()
		{
			
			Helper.click(searchButton);
		}
		
		public void clickSearchTextBox()
		{
			Helper.click(searchTextBox);
		}
		
		public void typeSearchInputTextBox(String text)
		{
			Helper.typeInputTextBox(searchTextBox, text);
		}
}