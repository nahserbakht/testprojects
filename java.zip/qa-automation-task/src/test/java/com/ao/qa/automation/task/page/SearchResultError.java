package com.ao.qa.automation.task.page;

import org.openqa.selenium.By;

import com.ao.qa.automation.task.util.Helper;

public class SearchResultError extends Page
{
	By errorMessageTitle;	
	
	public SearchResultError()
	{
		super("searchResultError");
		buildPage();
	}

	private void buildPage()
	{
		errorMessageTitle = By.xpath("//div[@id='zeroResultsWrapper']//h1");		
	} 

	public String getErrorMessageTitle()
	{
		return Helper.getText(errorMessageTitle);
	}
	
	public boolean isErrorMessageDisplayed()
	{
		return Helper.elementIsDisplayed(errorMessageTitle);
	}
}
