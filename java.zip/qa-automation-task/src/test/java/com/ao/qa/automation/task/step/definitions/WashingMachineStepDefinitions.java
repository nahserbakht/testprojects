package com.ao.qa.automation.task.step.definitions;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.number.OrderingComparison.greaterThanOrEqualTo;
import cucumber.api.java.Before;
import cucumber.api.java.After;


import com.ao.qa.automation.task.component.OverLay;
import com.ao.qa.automation.task.page.Home;
import com.ao.qa.automation.task.page.SearchResult;
import com.ao.qa.automation.task.page.SearchResultBrand;
import com.ao.qa.automation.task.page.SearchResultError;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WashingMachineStepDefinitions extends BaseTest {

	Home home;
	SearchResult searchResult;
	SearchResultBrand searchResultBrand;
	SearchResultError searchResultError;
	List<Integer> actualCustomerRatingsList;
	int expectedCustomerRating;
	OverLay overLay;
	String actualSearchResultTitle;
	String actualBrandName;

    @Before
    public void setUp() 
    {
    	super.setUp();
    	home = new Home();
    	searchResult = new SearchResult();
    	searchResultBrand = new SearchResultBrand();
    	searchResultError = new SearchResultError();
    	actualCustomerRatingsList = new ArrayList<Integer>();
    	overLay = new OverLay();
    	actualSearchResultTitle = new String();
    	actualBrandName = new String();
    }

    @After
    public void tearDown() 
    {
        super.tearDown();
    }
	
    @Given("^I am on the AO website$")
    public void iAmOnTheAOWebsite() 
    {
    	// Arrange 
    	String expectedUrl = "http://ao.com/";
    	
    	// Act
    	home.goToPage();
    	overLay.ignoreOverLay();
    	
    	// Assert
    	assertEquals(expectedUrl, home.getCurrentUrl());
    }

    @When("^I click on the search button$")
    public void iClickOnTheSearchButton() throws InterruptedException 
    {
    	// Act
    	home.header().search().clickSearchButton();
    	
    	if( ! searchResultError.isErrorMessageDisplayed() )
    	{
    		actualSearchResultTitle = searchResult.getMainTitle();
    	}
    	else
    	{
    		actualSearchResultTitle = searchResultError.getErrorMessageTitle();
    	}
    	
    }

    @When("^I click on the search engine text box$")
    public void iClickOnTheSearchEngineTextBox() 
    {
    	// Act
    	home.header().search().clickSearchTextBox();
    }

    @When("^I filter the results by the brand name \"([^\"]*)\"$")
    public void iFilterTheResultsByTheBrandName(String brandName) 
    {
    	// Act
    	searchResult.clickBrandNameLink(brandName);
    	
    	actualBrandName = searchResultBrand.getBrandNameTitle();
    }

    @When("^I filter the results by the customer rating of \"([^\"]*)\" stars$")
    public void iFilterTheResultsByTheCustomerRatingStars(String customerRating) throws InterruptedException 
    {
    	// Arrange
    	int numericCustomerRating = Integer.parseInt(customerRating);
    	
    	// Act
    	
    	searchResultBrand.filter().clickMoreFilterOptions();
    	searchResultBrand.filter().clickCustomerRatingLink();
    	searchResultBrand.filter().customerRatingValueOf(numericCustomerRating);
    	searchResultBrand.filter().clickCustomerRatingFromSelection();
    	
    	actualCustomerRatingsList = convertListToWholeNumbers(searchResultBrand.getCustomerRatings());
    	
    }
    
    @When("^I type in the search term \"([^\"]*)\"$")
    public void iTypeInTheSearchTerm(String searchTerm) 
    {
    	// Act
    	home.header().search().typeSearchInputTextBox(searchTerm);
    }

    @Then("^I should get an appropriate error message of (.*)$")
    public void iShouldGetAnAppropriateErrorMessage(String expectedErrorMessage)
    {    	
    	// Assert
    	assertEquals(expectedErrorMessage, actualSearchResultTitle);
    }

    @Then("^I should get a set of results based on the customer rating of \"([^\"]*)\" stars or above$")
    public void iShouldGetASetOfResultsBasedOnTheCustomerRatingStars(String customerRating) 
    {    	
    	// Act
    	expectedCustomerRating = Integer.parseInt(customerRating);    	
    	
    	// Assert
    	assertThat(actualCustomerRatingsList, everyItem(greaterThanOrEqualTo(expectedCustomerRating)));   	
    }

    @Then("^I should get a set of results based on the product brand name with heading of \"([^\"]*)\"$")
    public void iShouldGetASetOfResultsBasedOnTheProductBrandName(String expectedBrandName) 
    {   	
    	// Assert
    	assertEquals(expectedBrandName, actualBrandName);
    }

    @Then("^I should get a set of results based on the product type of \"([^\"]*)\"$")
    public void iShouldGetASetOfResultsBasedOnTheProductType(String expectedSearchResult) 
    {
    	// Assert
    	assertEquals(expectedSearchResult, actualSearchResultTitle);
    }
}
