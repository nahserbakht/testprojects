package com.ao.qa.automation.task.component;

import org.openqa.selenium.By;

import com.ao.qa.automation.task.util.Helper;

public class Header
{	
	private By homeLogo;
	private Search search;

	public Header()
	{	
		buildComponent();
	}

	private void buildComponent()
    {
		homeLogo = By.className("aoSiteLogoLink");
		search = new Search();		
    }
    
	public void clickHomeLogo()
	{
		Helper.click(homeLogo);
	}
	
	public Search search()
	{
		return search;
	}
}